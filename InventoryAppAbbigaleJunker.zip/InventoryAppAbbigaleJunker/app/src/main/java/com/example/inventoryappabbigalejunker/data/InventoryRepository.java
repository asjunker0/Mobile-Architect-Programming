// Tiny wrapper with easy CRUD calls
package com.example.inventoryappabbigalejunker.data;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class InventoryRepository {
    private final InventoryDbHelper dbh;

    public InventoryRepository(Context ctx){ dbh = new InventoryDbHelper(ctx);}

    // --- Auth ---
    public boolean userExists(String username){
        SQLiteDatabase db = dbh.getReadableDatabase();
        try (Cursor c = db.query(InventoryDbHelper.T_USERS, null,
                InventoryDbHelper.U_USERNAME + "=?",
                new String[]{username}, null, null, null)){
            return c.moveToFirst();
        }
    }

    public boolean login(String username, String password){
        SQLiteDatabase db = dbh.getReadableDatabase();
        try(Cursor c = db.query(InventoryDbHelper.T_USERS, null,
                InventoryDbHelper.U_USERNAME + "=? AND " + InventoryDbHelper.U_PASSWORD + "=?",
                new String[]{username, password}, null, null, null)){
            return c.moveToFirst();
        }
    }

    public void register(String username, String password) {
        SQLiteDatabase db = dbh.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(InventoryDbHelper.U_USERNAME, username);
        cv.put(InventoryDbHelper.U_PASSWORD, password);
        db.insertOrThrow(InventoryDbHelper.T_USERS, null, cv);
    }

    // --- Items CRUD ---
    public long addItem(String name, int qty){
        SQLiteDatabase db = dbh.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(InventoryDbHelper.I_NAME, name);
        cv.put(InventoryDbHelper.I_QTY, qty);
        return db.insert(InventoryDbHelper.T_ITEMS, null, cv);
    }

    public void updateItem(long id, String name, int qty){
        SQLiteDatabase db = dbh.getWritableDatabase();
        ContentValues cv = new ContentValues();
        cv.put(InventoryDbHelper.I_NAME, name);
        cv.put(InventoryDbHelper.I_QTY, qty);
        db.update(InventoryDbHelper.T_ITEMS, cv, InventoryDbHelper.I_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public void deleteItem(long id){
        SQLiteDatabase db = dbh.getWritableDatabase();
        db.delete(InventoryDbHelper.T_ITEMS, InventoryDbHelper.I_ID + "=?",
                new String[]{String.valueOf(id)});
    }

    public void changeQty(long id, int delta){
        SQLiteDatabase db = dbh.getWritableDatabase();
        db.execSQL("UPDATE " + InventoryDbHelper.T_ITEMS + " SET " +
                InventoryDbHelper.I_QTY + " = " + InventoryDbHelper.I_QTY + " + ? WHERE " +
                InventoryDbHelper.I_ID + " = ?", new Object[]{delta, id});
    }

    public Item getItemById(long id) {
        for (Item i : getAllItems()){
            if (i.id == id) return i;
        }
        return null;
    }

    public static class Item {
        public long id; public String name; public int qty;
    }

    public List<Item> getAllItems() {
        SQLiteDatabase db = dbh.getReadableDatabase();
        List<Item> out = new ArrayList<>();
        try (Cursor c = db.query(InventoryDbHelper.T_ITEMS, null, null, null, null, null,
                InventoryDbHelper.I_NAME + " ASC")) {
            while (c.moveToNext()) {
                Item it = new Item();
                it.id = c.getLong(c.getColumnIndexOrThrow(InventoryDbHelper.I_ID));
                it.name = c.getString(c.getColumnIndexOrThrow(InventoryDbHelper.I_NAME));
                it.qty = c.getInt(c.getColumnIndexOrThrow(InventoryDbHelper.I_QTY));
                out.add(it);
            }
        }
        return out;
    }

    public List<Item> getZeroItems() {
        SQLiteDatabase db = dbh.getReadableDatabase();
        List<Item> out = new ArrayList<>();
        try (Cursor c = db.query(InventoryDbHelper.T_ITEMS, null,
                InventoryDbHelper.I_QTY + "<=0", null, null, null, null)) {
            while (c.moveToNext()) {
                Item it = new Item();
                it.id = c.getLong(c.getColumnIndexOrThrow(InventoryDbHelper.I_ID));
                it.name = c.getString(c.getColumnIndexOrThrow(InventoryDbHelper.I_NAME));
                it.qty = c.getInt(c.getColumnIndexOrThrow(InventoryDbHelper.I_QTY));
                out.add(it);
            }
        }
        return out;
    }
}