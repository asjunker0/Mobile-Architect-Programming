// Permission request + send SMS (only if granted)
package com.example.inventoryappabbigalejunker.util;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import android.widget.Toast;

import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SmsHelper {
    private static final int REQ_SMS = 101;

    public static void sendZeroAlert(Activity act, String phone, String message){
        if (ContextCompat.checkSelfPermission(act, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(act, new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
            return;
        }
        try {
            SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
            Toast.makeText(act, "SMS alert sent", Toast.LENGTH_SHORT).show();
        } catch(Exception e) {
            Toast.makeText(act, "Failed to send SMS", Toast.LENGTH_SHORT).show();
        }
    }
}
