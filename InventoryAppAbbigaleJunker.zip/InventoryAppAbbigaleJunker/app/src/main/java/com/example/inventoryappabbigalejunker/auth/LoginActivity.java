// Handles login & new account creation
package com.example.inventoryappabbigalejunker.auth;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryappabbigalejunker.R;
import com.example.inventoryappabbigalejunker.data.InventoryRepository;
import com.example.inventoryappabbigalejunker.ui.MainActivity;

public class LoginActivity extends AppCompatActivity {
    private InventoryRepository repo;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        repo = new InventoryRepository(this);

        EditText etUsername = findViewById(R.id.etUsername);
        EditText etPassword = findViewById(R.id.etPassword);
        Button btnLogin = findViewById(R.id.btnLogin);
        Button btnCreate = findViewById(R.id.btnCreate);

        // btnLogin behavior
        btnLogin.setOnClickListener(v -> {
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString().trim();
            if (repo.login(u, p)) {
                goHome(u);
            } else {
                Toast.makeText(this, "Invalid login", Toast.LENGTH_SHORT).show();
            }
        });

        // btnCreate behavior
        btnCreate.setOnClickListener(v -> {
            String u = etUsername.getText().toString().trim();
            String p = etPassword.getText().toString().trim();
            if (u.isEmpty() || p.isEmpty()) { Toast.makeText(this, "Enter both fields,", Toast.LENGTH_SHORT).show(); return;}
            if (repo.userExists(u)) { Toast.makeText(this, "Username exists", Toast.LENGTH_SHORT).show(); return;}
            repo.register(u,p);
            Toast.makeText(this, "Account created. Logging in!", Toast.LENGTH_SHORT).show();
            goHome(u);
        });
    }

    private void goHome(String username) {
        Intent i = new Intent(this, MainActivity.class);
        i.putExtra("username", username);
        startActivity(i);
        finish();
    }

}
