// SQLite helper (creates 2 tables: users, items)
package com.example.inventoryappabbigalejunker.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class InventoryDbHelper extends SQLiteOpenHelper {
    public static final String DB_NAME = "inventory.db";
    public static final int DB_VERSION = 1;

    // users table in activity_login
    public static final String T_USERS = "users";
    public static final String U_USERNAME = "username";
    public static final String U_PASSWORD = "password";

    // items table in activity_main
    public static final String T_ITEMS = "items";
    public static final String I_ID = "_id";
    public static final String I_NAME = "name";
    public static final String I_QTY = "quantity";

    public InventoryDbHelper(Context context){
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db){
        // users table
        db.execSQL("CREATE TABLE " + T_USERS + " (" +
                U_USERNAME + " TEXT PRIMARY KEY, " +
                U_PASSWORD + " TEXT NOT NULL)");

        // items table
        db.execSQL("CREATE TABLE " + T_ITEMS + " (" +
                I_ID   + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                I_NAME + " TEXT NOT NULL, " +
                I_QTY  + " INTEGER NOT NULL DEFAULT 0" +
                ")");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + T_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + T_ITEMS);
        onCreate(db);
    }
}