// Lets the user store a phone number for SMS alerts
package com.example.inventoryappabbigalejunker.ui;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.example.inventoryappabbigalejunker.R;

public class SettingsActivity extends AppCompatActivity {

    private static final int REQ_SMS = 101;
    private EditText etPhone;
    private TextView smsStatus;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_settings);

        etPhone = findViewById(R.id.etPhone);
        smsStatus = findViewById(R.id.smsStatus);
        Button enableSmsBtn = findViewById(R.id.enableSmsBtn);
        Button backBtn = findViewById(R.id.backBtn);

        prefs = getSharedPreferences("settings", MODE_PRIVATE);
        String savedPhone = prefs.getString("alert_phone", "");
        if (!savedPhone.isEmpty()) {
            etPhone.setText(savedPhone);
            smsStatus.setText("Status: Enabled for " + savedPhone);
        }

        // enableSmsBtn behavior
        enableSmsBtn.setOnClickListener(v -> {
            String phone = etPhone.getText().toString().trim();
            if(phone.isEmpty()){
                Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show();
                return;
            }

            prefs.edit().putString("alert_phone", phone).apply();
            smsStatus.setText("Status: Enabled for " + phone);

            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
            != PackageManager.PERMISSION_GRANTED){
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS}, REQ_SMS);
            } else {
                sendTestSms(phone);
            }
        });


        // btnBack behavior
        backBtn.setOnClickListener(v -> {
            Intent i = new Intent(this, MainActivity.class);
            startActivity(i);
            finish();
        });
    }

    private void sendTestSms(String phone){
        try {
            SmsManager.getDefault().sendTextMessage(phone, null,
                    "SMS alerts enabled for your Inventory App!", null, null);
            Toast.makeText(this, "Test SMS sent :)", Toast.LENGTH_SHORT).show();
        } catch (Exception e){
            Toast.makeText(this, "SMS failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        TextView smsStatus = findViewById(R.id.smsStatus);
        EditText etPhone = findViewById(R.id.etPhone);

        if (requestCode == 1) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                String phone = etPhone.getText().toString().trim();
                getSharedPreferences("settings", MODE_PRIVATE)
                        .edit().putString("alert_phone", phone).apply();
                smsStatus.setText("Status: Enabled for " + phone);
            } else {
                smsStatus.setText("Status: Permission denied");
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        TextView smsStatus = findViewById(R.id.smsStatus);
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        String phone = prefs.getString("alert_phone", "");
        boolean granted = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;

        if (granted && !phone.isEmpty()) {
            smsStatus.setText("Status: Enabled for " + phone);
        } else {
            smsStatus.setText("Status: SMS notifications disabled");
        }
    }
}
