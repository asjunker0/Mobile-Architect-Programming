// Add or edit a single item
package com.example.inventoryappabbigalejunker.ui;

import android.os.Bundle;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

import com.example.inventoryappabbigalejunker.R;
import com.example.inventoryappabbigalejunker.data.InventoryRepository;

public class AddEditItemActivity extends AppCompatActivity {
    private InventoryRepository repo;
    private long editId = -1;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_add_edit_item);

        repo = new InventoryRepository(this);

        EditText etName = findViewById(R.id.etName);
        EditText etQty = findViewById(R.id.etQty);
        Button btnSave = findViewById(R.id.btnSave);

        editId = getIntent().getLongExtra("_id", -1);
        if (editId != -1){
            // prefill from existing list
            InventoryRepository.Item existing = null;
            for (InventoryRepository.Item it : repo.getAllItems()){
                if (it.id == editId){
                    existing = it;
                    break;
                }
            }

            if (existing != null){
                etName.setText(existing.name);
                etQty.setText(String.valueOf(existing.qty));
            }
        }

        btnSave.setOnClickListener(v -> {
            String name = etName.getText().toString().trim();
            String qtyStr = etQty.getText().toString().trim();
            int qty = TextUtils.isEmpty(qtyStr) ? 0 : Integer.parseInt(qtyStr);

            if(name.isEmpty()) { etName.setError("Required"); return;}

            if(editId == -1) repo.addItem(name, qty);
            else repo.updateItem(editId, name, qty);
            finish();
        });
    }
}
