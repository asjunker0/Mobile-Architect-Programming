// RecyclerView adapter
package com.example.inventoryappabbigalejunker.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryappabbigalejunker.R;
import com.example.inventoryappabbigalejunker.data.InventoryRepository;
import java.util.List;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {

    public interface Listener {
        void onEdit(InventoryRepository.Item item);
        void onDelete(InventoryRepository.Item item);
        void onInc(InventoryRepository.Item item);
        void onDec(InventoryRepository.Item item);
    }

    private List<InventoryRepository.Item> data;
    private final Listener listener;

    public ItemAdapter(List<InventoryRepository.Item> data, Listener l) {
        this.data = data; this.listener = l;
    }

    public void submit(List<InventoryRepository.Item> newData) {this.data = newData; notifyDataSetChanged();}

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        return new VH(v);
    }

    @Override public void onBindViewHolder(@NonNull VH h, int pos){
        InventoryRepository.Item it = data.get(pos);
        h.name.setText(it.name);
        h.qty.setText(String.valueOf(it.qty));
        h.id.setText("ID: " + it.id);
        h.btnEdit.setOnClickListener(v -> listener.onEdit(it));
        h.btnDelete.setOnClickListener(v -> listener.onDelete(it));
        h.btnInc.setOnClickListener(v -> listener.onInc(it));
        h.btnDec.setOnClickListener(v -> listener.onDec(it));
        // Visual flag of zero qty
        h.itemView.setAlpha(it.qty <= 0 ? 0.7f : 1f);
    }

    @Override public int getItemCount(){return data.size();}

    static class VH extends RecyclerView.ViewHolder {
        TextView name, qty, id; Button btnInc, btnDec, btnEdit, btnDelete;
        VH(View v){
            super(v);
            name = v.findViewById(R.id.tvName);
            qty = v.findViewById(R.id.tvQty);
            id = v.findViewById(R.id.tvId);
            btnInc = v.findViewById(R.id.btnInc);
            btnDec = v.findViewById(R.id.btnDec);
            btnEdit = v.findViewById(R.id.btnEdit);
            btnDelete = v.findViewById(R.id.btnDelete);
        }
    }
}
