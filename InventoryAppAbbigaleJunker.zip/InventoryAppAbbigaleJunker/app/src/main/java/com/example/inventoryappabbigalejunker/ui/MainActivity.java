// Shows grid, increments/decrements, delete
package com.example.inventoryappabbigalejunker.ui;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.inventoryappabbigalejunker.R;
import com.example.inventoryappabbigalejunker.data.InventoryRepository;
import com.example.inventoryappabbigalejunker.ui.adapter.ItemAdapter;
import com.example.inventoryappabbigalejunker.util.SmsHelper;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private InventoryRepository repo;
    private ItemAdapter adapter;

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        repo = new InventoryRepository(this);

        RecyclerView rv = findViewById(R.id.recyclerItems);
        rv.setLayoutManager(new LinearLayoutManager(this));
        adapter = new ItemAdapter(repo.getAllItems(), new ItemAdapter.Listener() {
            @Override
            public void onEdit(InventoryRepository.Item item) {
                Intent i = new Intent(MainActivity.this, AddEditItemActivity.class);
                i.putExtra("_id", item.id);
                startActivity(i);
            }

            @Override
            public void onDelete(InventoryRepository.Item item) {
                repo.deleteItem(item.id);
                refresh();
            }

            @Override
            public void onInc(InventoryRepository.Item item) {
                repo.changeQty(item.id, +1);
                refresh();
            }

            @Override
            public void onDec(InventoryRepository.Item item) {
                repo.changeQty(item.id, -1);
                refresh();

                // Get the updated item’s quantity
                InventoryRepository.Item updated = repo.getItemById(item.id);
                if (updated != null && updated.qty <= 0) {
                    checkZerosAndMaybeSms();
                }
            }
        });
        rv.setAdapter(adapter);

        Button btnAdd = findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(v -> startActivity(new Intent(this, AddEditItemActivity.class)));

        Button btnSettings = findViewById(R.id.btnSettings);
        btnSettings.setOnClickListener(v -> startActivity(new Intent(this, SettingsActivity.class)));
    }

    @Override protected void onResume(){
        super.onResume();
        refresh();
        checkZerosAndMaybeSms();
    }

    private void refresh(){
        List<InventoryRepository.Item> items = repo.getAllItems();
        adapter.submit(items);
    }

    private void checkZerosAndMaybeSms(){
        List<InventoryRepository.Item> zeros = repo.getZeroItems();
        if(zeros.isEmpty()) return;

        // in app notification
        StringBuilder names = new StringBuilder();
        for (InventoryRepository.Item z : zeros) {
            names.append("♡ ").append(z.name).append(" (qty ").append(z.qty).append(")\n");
        }
        new AlertDialog.Builder(this)
                .setTitle("Low/Zero Inventory")
                .setMessage("These items are at zero or less:\n\n" + names.toString())
                .setPositiveButton("OK", null)
                .show();

        // SMS notifications if wanted
        SharedPreferences prefs = getSharedPreferences("settings", MODE_PRIVATE);
        String phone = prefs.getString("alert_phone", "");
        if(!phone.isEmpty()){
            String msg = "Zero inventory: " + zeros.get(0).name + (zeros.size() > 1 ? " + more" : "");
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED && !phone.isEmpty()) {
                SmsHelper.sendZeroAlert(this, phone, msg);
            }
        }
    }

}
